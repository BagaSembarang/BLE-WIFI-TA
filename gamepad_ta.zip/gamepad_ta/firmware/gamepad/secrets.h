// secrets.h - kredensial Wi-Fi router. EDIT file ini, lalu upload. JANGAN di-commit ke repo publik.
#pragma once
#define WIFI_SSID  "NAMA_WIFI_ROUTER"
#define WIFI_PASS  "SANDI_WIFI_ROUTER"
